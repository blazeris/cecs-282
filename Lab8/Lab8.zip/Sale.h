// Nathan Lai
// CECS 282 Lab 8

#ifndef PUBLICATION_SALE_H
#define PUBLICATION_SALE_H

#include <iostream>

using namespace std;

class Sale {
public:
	void getData();
	void putData();

protected:
    float saleArray[3];
};

#endif //PUBLICATION_SALE_H
