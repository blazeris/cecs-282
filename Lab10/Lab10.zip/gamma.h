//
// Created by Nathan
//

#ifndef LAB10_GAMMA_H
#define LAB10_GAMMA_H


class gamma {
private:
    static int total ;
    int id;
public:
    gamma();
    ~gamma();
    static void showtotal();
    void showid();

};


#endif //LAB10_GAMMA_H
