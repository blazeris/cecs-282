// Nathan Lai
// CECS 282 Project - Part 1
#ifndef EMPLOYEEINFO_H
#define EMPLOYEEINFO_H

class EmployeeInfo {
	public:
		const static double FACULTY_MONTHLY_SALARY = 5000.00;
		const static double STAFF_MONTHLY_HOURS_WORKED = 160;
};


#endif
