// Nathan Lai
// CECS 282 Project - Part 1
#include "PartTime.h"


PartTime::PartTime():Staff(){
	hoursPerWeek = 0;
}

PartTime::PartTime(string lastName, string firstName, string idNumber, Sex s, string date, double hourlyRate, int hoursPerWeek):
	Staff(lastName, firstName, idNumber, s, date, hourlyRate){
	this->hoursPerWeek = hoursPerWeek;
}

int PartTime::getHoursPerWeek(){
	return hoursPerWeek;
}

void PartTime::setHoursPerWeek(int hoursPerWeek){
	this->hoursPerWeek = hoursPerWeek;
}

double PartTime::monthlyEarning(){
	return hoursPerWeek * Staff::getHourlyRate();
}

void PartTime::putData(){
	Employee::putData();
	cout << "Hours worked per month: " << 4 * hoursPerWeek << endl;
	cout << "Monthly Salary: $" << monthlyEarning() << endl;
}
